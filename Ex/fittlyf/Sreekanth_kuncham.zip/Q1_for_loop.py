a = [1,2,3,4,5,6]

for i in a:
	print(i**2)
print("The sequence has ended")